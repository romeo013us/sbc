'use strict';
const crypto = require('crypto');
const V452 = require('./v452-operations-hardening');

function createSessionStore({
  sessionSecret,
  mysqlPool,
  getRedisClient,
  isRedisReady,
  getUsers,
  jwtVerify,
  tenantDefaultId=1,
  ttlMs=604800000,
  logger=console
}) {
  const SESSION_TTL_MS=Math.max(5*60*1000,Number(ttlMs)||604800000);
  // V45.2: session cache is isolated in a dedicated worker-thread partition.
  // No employee/session records are retained in the main-thread process-local Map.
  const persistTimeoutMs=5000;
  const withTimeout=(promise,ms)=>{let timer;return Promise.race([Promise.resolve(promise),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('session store timeout')),ms);timer.unref?.();})]).finally(()=>{if(timer)clearTimeout(timer)});};
  const mysqlQuery=(sql,params=[])=>mysqlPool.query({sql,timeout:persistTimeoutMs},params);
  function sessionHash(token){return crypto.createHash('sha256').update(String(token)).digest('hex')}
  function sessionRedisKey(token){return `sbc:session:${sessionHash(token)}`}
  function sign(raw){return crypto.createHmac('sha256',String(sessionSecret||'')).update(raw).digest('hex')}
  function sessionCookieToken(req){const raw=req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith('sbc_session='))?.slice('sbc_session='.length)||'';try{return decodeURIComponent(raw.replace(/^\"|\"$/g,''))}catch{return raw.replace(/^\"|\"$/g,'')}}
  function makeSession(user){const raw=crypto.randomBytes(24).toString('hex');const token=raw+'.'+sign(raw);const createdAt=Date.now(),expiresAt=createdAt+SESSION_TTL_MS;return {token,record:{createdAt,userId:user.id,role:String(user.role||''),tenantId:Number(user.tenantId||tenantDefaultId),expiresAt}}}
  async function persistSession(token,rec){
    try{await withTimeout(V452.cacheSet(`session:${sessionHash(token)}`,rec,Math.max(1000,rec.expiresAt-Date.now())),persistTimeoutMs)}catch(e){logger.warn('[SBC AUTH] isolated session cache write:',e.message)}
    let redisDurable=false,mysqlDurable=false;
    const redis=getRedisClient();
    if(isRedisReady()&&redis){try{const ttl=Math.max(1,Math.ceil((rec.expiresAt-Date.now())/1000));await withTimeout(redis.set(sessionRedisKey(token),JSON.stringify(rec),{EX:ttl}),persistTimeoutMs);redisDurable=true;}catch(e){logger.warn('[SBC AUTH] Redis session write:',e.message)}}
    if(mysqlPool){try{await withTimeout(mysqlQuery(`INSERT INTO sbc_sessions(token_hash,user_id,created_at,expires_at,last_seen_at) VALUES (?,?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),expires_at=VALUES(expires_at),last_seen_at=UTC_TIMESTAMP()`,[sessionHash(token),rec.userId,new Date(rec.createdAt).toISOString().slice(0,19).replace('T',' '),new Date(rec.expiresAt).toISOString().slice(0,19).replace('T',' ')]),persistTimeoutMs+250);mysqlDurable=true;}catch(e){logger.warn('[SBC AUTH] MySQL session write:',e.message)}}
    if(mysqlPool){try{await withTimeout(mysqlQuery('INSERT INTO sbc_session_bindings(token_hash,role,created_at) VALUES (?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE role=VALUES(role)',[sessionHash(token),String(rec.role||'')]),persistTimeoutMs+250)}catch(e){logger.warn('[SBC AUTH] MySQL role binding write:',e.message)}}
    return {durable:Boolean(redisDurable||mysqlDurable),redis:redisDurable,mysql:mysqlDurable,localFallback:false};
  }
  async function dropSession(token){
    if(!token)return {cacheCleared:false,redisCleared:false,mysqlCleared:false};
    const hash=sessionHash(token);const result={cacheCleared:false,redisCleared:false,mysqlCleared:false};
    try{await withTimeout(V452.cacheDelete(`session:${hash}`),persistTimeoutMs);result.cacheCleared=true}catch(e){logger.warn('[SBC AUTH] isolated session cache cleanup:',e.message)}
    const cleanup=[];const redis=getRedisClient();
    if(isRedisReady()&&redis)cleanup.push(withTimeout(redis.del(sessionRedisKey(token)),persistTimeoutMs).then(()=>{result.redisCleared=true}).catch(e=>logger.warn('[SBC AUTH] Redis session cleanup:',e.message)));
    if(mysqlPool)cleanup.push(Promise.all([
      withTimeout(mysqlQuery('DELETE FROM sbc_sessions WHERE token_hash=?',[hash]),persistTimeoutMs+250),
      withTimeout(mysqlQuery('DELETE FROM sbc_session_bindings WHERE token_hash=?',[hash]),persistTimeoutMs+250)
    ]).then(()=>{result.mysqlCleared=true}).catch(e=>logger.warn('[SBC AUTH] MySQL session cleanup:',e.message)));
    await Promise.all(cleanup);return result;
  }
  async function sessionUser(req){
    if(process.env.SBC_AUTH_MODE==='jwt'){const authHeader=String(req.headers.authorization||'');if(authHeader.startsWith('Bearer ')){const claims=jwtVerify(authHeader.slice(7).trim());if(claims?.sub){const u=(getUsers()||[]).find(x=>x.id===claims.sub&&x.active!==false);if(u){u.tenantId=Number(claims.tenantId||u.tenantId||tenantDefaultId);return u;}}}}
    const token=sessionCookieToken(req);if(!token)return null;let rec=await V452.cacheGet(`session:${sessionHash(token)}`).catch(()=>null);const redis=getRedisClient();
    if(isRedisReady()&&redis){try{const raw=await redis.get(sessionRedisKey(token));if(raw)rec=JSON.parse(raw);}catch(e){logger.warn('[SBC AUTH] Redis session read:',e.message)}}
    if(!rec&&mysqlPool){try{const [rows]=await withTimeout(mysqlQuery('SELECT user_id,UNIX_TIMESTAMP(created_at)*1000 AS created_ms,UNIX_TIMESTAMP(expires_at)*1000 AS expires_ms,UNIX_TIMESTAMP(last_seen_at)*1000 AS last_seen_ms FROM sbc_sessions WHERE token_hash=? AND expires_at>=UTC_TIMESTAMP() LIMIT 1',[sessionHash(token)]),persistTimeoutMs+250);if(rows[0]){rec={createdAt:Number(rows[0].created_ms),userId:rows[0].user_id,tenantId:tenantDefaultId,expiresAt:Number(rows[0].expires_ms)};try{const [br]=await withTimeout(mysqlQuery('SELECT role FROM sbc_session_bindings WHERE token_hash=? LIMIT 1',[sessionHash(token)]),persistTimeoutMs+250);rec.role=String(br[0]?.role||'')}catch(e){logger.warn('[SBC AUTH] session role binding read:',e.message)}if(isRedisReady()&&redis){const ttl=Math.max(1,Math.ceil((rec.expiresAt-Date.now())/1000));redis.set(sessionRedisKey(token),JSON.stringify(rec),{EX:ttl}).catch(()=>{})}withTimeout(mysqlQuery('UPDATE sbc_sessions SET last_seen_at=UTC_TIMESTAMP() WHERE token_hash=?',[sessionHash(token)]),persistTimeoutMs+250).catch(()=>{})}}catch(e){logger.warn('[SBC AUTH] durable session read unavailable:',e.message);const unavailable=new Error('Session store temporarily unavailable.');unavailable.code='SESSION_STORE_UNAVAILABLE';throw unavailable}}
    if(!rec)return null;if(Date.now()>Number(rec.expiresAt||Number(rec.createdAt)+SESSION_TTL_MS)){await dropSession(token);return null}
    const u=(getUsers()||[]).find(x=>x.id===rec.userId&&x.active!==false);if(u&&rec.role&&String(u.role||'')!==String(rec.role))return (await dropSession(token),null);if(u?.expiresAt&&new Date(u.expiresAt+'T23:59:59')<new Date()){u.active=false;await dropSession(token);return null}return u||null;
  }
  async function validSession(req){return Boolean(await sessionUser(req))}
  async function cleanupExpired(){if(mysqlPool){try{const [r]=await withTimeout(mysqlQuery('DELETE FROM sbc_sessions WHERE expires_at < UTC_TIMESTAMP()'),persistTimeoutMs+250);return {mysqlDeleted:Number(r.affectedRows||0)}}catch(e){logger.warn('[SBC AUTH] session cleanup:',e.message)}}return {mysqlDeleted:0}}
  async function redisHealth(){const redis=getRedisClient();if(!isRedisReady()||!redis)return {configured:false,ready:false,sessionKeyCount:null,ttlSeconds:null};let count=0,ttl=null,cursor='0';try{do{const out=await redis.scan(cursor,{MATCH:'sbc:session:*',COUNT:250});cursor=String(out.cursor);const keys=out.keys||[];count+=keys.length;if(ttl===null&&keys[0])ttl=await redis.ttl(keys[0]);}while(cursor!=='0');return {configured:true,ready:true,sessionKeyCount:count,ttlSeconds:ttl,ttlEnforced:ttl===null||ttl>0};}catch(e){return {configured:true,ready:false,error:e.message}}}
  return {sessionHash,sessionRedisKey,sessionCookieToken,makeSession,persistSession,dropSession,sessionUser,validSession,cleanupExpired,redisHealth};
}
module.exports={createSessionStore};
