'use strict';

const TRANSIENT_CODES = new Set([
  'PROTOCOL_CONNECTION_LOST', 'ECONNRESET', 'EPIPE', 'ETIMEDOUT',
  'ECONNREFUSED', 'EHOSTUNREACH', 'ER_CLIENT_INTERACTION_TIMEOUT',
  'ER_LOCK_DEADLOCK', 'ER_LOCK_WAIT_TIMEOUT', 'ECONNABORTED'
]);

function isTransientMySQLError(error) {
  const code = String(error?.code || '').toUpperCase();
  const message = String(error?.message || error || '').toLowerCase();
  return TRANSIENT_CODES.has(code) || /packets out of order|client was disconnected|connection.*closed|connection.*lost|socket.*closed|closed state|inactivity|interaction timeout|broken pipe|epipe/.test(message);
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function isConnectionFailure(error) {
  const code = String(error?.code || '').toUpperCase();
  const message = String(error?.message || error || '').toLowerCase();
  return new Set(['PROTOCOL_CONNECTION_LOST','ECONNRESET','EPIPE','ETIMEDOUT','ECONNREFUSED','EHOSTUNREACH','ER_CLIENT_INTERACTION_TIMEOUT','ECONNABORTED']).has(code) || /packets out of order|client was disconnected|connection.*closed|connection.*lost|socket.*closed|closed state|inactivity|interaction timeout|broken pipe|epipe/.test(message);
}


function destroyQuietly(conn) {
  try { conn?.destroy?.(); } catch {}
}

function releaseQuietly(conn) {
  try { conn?.release?.(); } catch {}
}

function markBroken(conn) {
  try { conn.__sbcBroken = true; } catch {}
  destroyQuietly(conn);
}

function isBroken(conn) {
  return Boolean(conn?.__sbcBroken || conn?._fatalError || conn?._protocol?._fatalError || conn?._closed);
}

/**
 * Wrap one leased mysql2 connection. A transient socket/protocol failure
 * destroys that exact socket so it can never be returned to the pool.
 */
function wrapConnection(conn, {onRetry = () => {}} = {}) {
  if (!conn || conn.__sbcV6042ConnectionGuard) return conn;
  return new Proxy(conn, {
    get(target, prop, receiver) {
      if (prop === '__sbcV6042ConnectionGuard') return true;
      if (prop === '__sbcBroken') return target.__sbcBroken === true;
      if (['query', 'execute', 'ping', 'beginTransaction', 'commit'].includes(prop)) {
        return async function guardedConnectionMethod(...args) {
          if (isBroken(target)) throw Object.assign(new Error('SBC_MYSQL_BROKEN_CONNECTION'), {code:'SBC_MYSQL_BROKEN_CONNECTION'});
          try {
            return await target[prop](...args);
          } catch (error) {
            if (isConnectionFailure(error)) markBroken(target);
            throw error;
          }
        };
      }
      if (prop === 'rollback') {
        return async function guardedRollback(...args) {
          try { return await target.rollback(...args); }
          catch (error) { if (isConnectionFailure(error)) markBroken(target); throw error; }
        };
      }
      if (prop === 'release') {
        return function guardedRelease(...args) {
          if (isBroken(target)) { destroyQuietly(target); return; }
          return target.release(...args);
        };
      }
      if (prop === 'destroy') return (...args) => { markBroken(target); return target.destroy(...args); };
      return Reflect.get(target, prop, receiver);
    }
  });
}

/**
 * V60.4.2 pool guard.
 *
 * Ordinary query/execute calls explicitly lease a connection. On a transient
 * failure the poisoned socket is destroyed and the retry gets a fresh lease.
 * Transaction callers using getConnection() receive the same guarded socket.
 * We deliberately do NOT replay transactions here; transaction safety belongs
 * to the caller and its idempotency boundary.
 */
function wrapPool(pool, { attempts = 3, onRetry = () => {}, metrics = null } = {}) {
  if (!pool || pool.__sbcV6042Guard) return pool;
  const maxAttempts = Math.max(1, Math.min(4, Number(attempts) || 3));
  const stats = metrics || {queries:0,retries:0,recycled:0,failures:0,active:0};

  async function runFresh(method, args) {
    let last;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      let conn = null;
      try {
        stats.queries++;
        conn = await pool.getConnection();
        const guardedConn = wrapConnection(conn, {onRetry});
        const result = await guardedConn[method](...args);
        releaseQuietly(guardedConn);
        return result;
      } catch (error) {
        last = error;
        const transient = isTransientMySQLError(error);
        if (transient) {
          if (isConnectionFailure(error)) { stats.recycled++; markBroken(conn); }
          else releaseQuietly(conn);
        }
        if (!transient || attempt >= maxAttempts) {
          stats.failures++;
          throw error;
        }
        stats.retries++;
        const wait = Math.min(1200, 150 * (2 ** (attempt - 1)));
        try { onRetry({operation:method,attempt,wait,code:error?.code||'',message:String(error?.message||'')}); } catch {}
        await delay(wait);
      }
    }
    throw last;
  }

  const guarded = new Proxy(pool, {
    get(target, prop, receiver) {
      if (prop === '__sbcV6042Guard') return true;
      if (prop === '__sbcMysqlMetrics') return stats;
      if (prop === 'query' || prop === 'execute') return (...args) => runFresh(prop, args);
      if (prop === 'getConnection') {
        return async function guardedGetConnection(...args) {
          const conn = await target.getConnection(...args);
          return wrapConnection(conn, {onRetry});
        };
      }
      return Reflect.get(target, prop, receiver);
    }
  });
  return guarded;
}

module.exports = { wrapPool, isTransientMySQLError, wrapConnection };
