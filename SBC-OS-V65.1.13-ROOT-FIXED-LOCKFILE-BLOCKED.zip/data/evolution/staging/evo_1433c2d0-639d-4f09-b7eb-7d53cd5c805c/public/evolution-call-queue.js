// SANDBOX UI SCAFFOLD — not loaded by production Command Center.
export function sortCallQueue(rows){ return [...rows].sort((a,b)=>(b.priority_score||0)-(a.priority_score||0)); }
