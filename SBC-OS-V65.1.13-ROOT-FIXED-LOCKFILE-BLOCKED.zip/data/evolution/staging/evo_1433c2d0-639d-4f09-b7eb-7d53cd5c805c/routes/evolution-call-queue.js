'use strict';
// SANDBOX SCAFFOLD — not mounted by production routing.
function prioritize(row){ const age=row.last_contacted_at?Date.now()-new Date(row.last_contacted_at).getTime():Number.MAX_SAFE_INTEGER; return Math.min(100,50+(age>=48*3600000?40:10)+(row.phone?5:0)); }
module.exports={prioritize};
