# Miami Lead Verification Pack — 2026-10-04

This pack is owner-controlled. Do not auto-blast.

## Import
Use `miami-7-native-intake-import.csv` through the existing owner-only spreadsheet lead intake.

The native intake engine will normalize, deduplicate, score and leave records in `Needs Verification` until the system's verification gate clears them.

## Quarantine
`miami-288-synthetic-quarantine.csv` must not be imported.

## Review
`miami-5-business-verified-contact-review.csv` contains real-business candidates whose contact channel needs confirmation before CRM activation.
