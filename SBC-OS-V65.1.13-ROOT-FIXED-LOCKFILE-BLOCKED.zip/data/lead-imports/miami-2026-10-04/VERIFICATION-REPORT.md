# SBC Miami 300 Lead Verification — V56.13.3

Source: supplied miami-hot-leads-300.csv
Rows received: 300
Rows safe for immediate owner-controlled CRM import: 7
Business verified but contact channel requires manual confirmation: 5
Synthetic/generated rows quarantined: 288

## Critical finding
The supplied source explicitly states that the first seed businesses were followed by generated variations to reach 300 rows. The generated rows use fabricated 305-555 numbers, synthetic sbc-* domains, invented executive emails, and generated Google Maps query links. Those rows are NOT imported.

## Import policy
- VERIFIED_CONTACT_CHANNEL -> eligible for owner-controlled spreadsheet ingest and downstream verification.
- BUSINESS_VERIFIED_CONTACT_REVIEW -> held for manual contact verification.
- REJECTED_SYNTHETIC -> quarantined; never enters Revenue PLAY.
- WARM_CANDIDATE is a fit classification, NOT evidence of buyer intent.
- HOT/WAR is earned only after actual engagement/intent/verification through the Command Center.

## Verified contact-channel corrections
Panamera: +1 305-510-1229 / talk@panamera.co
Solved Puzzle: +1 305-487-7477 / info@solvedpuzzle.com
Heyday: +1 305-783-3407 / emoya@heydaymarketing.com
Jacober: +1 305-801-9291
Lemon Yellow: +1 305-704-7096 / hello@lemonyellow.com
Web Creation Design: +1 786-673-2439 / info@webcreationdesign.com
Levie: +1 305-219-4815 / hello@leviecreative.com

## Next production step
Import ONLY miami-7-verified-import-ready.csv through the owner-only lead intake endpoint/UI. Then let the native lead mesh perform normalization, dedupe, scoring, and verification. Do not auto-blast these records.
