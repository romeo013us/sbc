'use strict';
const RELEASE_VERSION = '65.1.13';
const RELEASE_NAME = 'RECOVERY-WRITE-FAILURE-HOTFIX';
const RELEASE = Object.freeze({version:RELEASE_VERSION,name:RELEASE_NAME,major:65,minor:1,patch:13});
module.exports = { RELEASE_VERSION, RELEASE_NAME, RELEASE };
