const CACHE='sbc-static-v56-25-1';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>/^sbc-static-v(?:55|56)-/.test(k)&&k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim();})()));
self.addEventListener('fetch',e=>{
  const r=e.request;
  const u=new URL(r.url);
  // Transaction/API traffic is always network-only. Never allow the service worker
  // to cache or replay payment, checkout, webhook, provisioning, or mutation requests.
  const networkOnly = r.method!=='GET' || u.pathname.includes('/api/') ||
    u.pathname.includes('/revenue-finisher') || u.pathname.includes('/square') ||
    u.pathname.includes('/webhooks/');
  if(networkOnly){ e.respondWith(fetch(r)); return; }
  e.respondWith(fetch(r).then(x=>{
    if(x && x.ok){ const c=x.clone(); caches.open(CACHE).then(cache=>cache.put(r,c)).catch(()=>{}); }
    return x;
  }).catch(()=>caches.match(r)));
});
self.addEventListener('sync',e=>{if(e.tag==='sbc-offline-sync')e.waitUntil((async()=>{const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('sbc-offline-v1',1);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});const rows=await new Promise((resolve,reject)=>{const q=db.transaction('mutations','readonly').objectStore('mutations').getAll();q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)});for(const x of rows){try{const r=await fetch(x.url,{method:x.method,headers:x.headers,body:x.body,credentials:'include'});if(r.ok){const tx=db.transaction('mutations','readwrite');tx.objectStore('mutations').delete(x.id)}}catch{break}}})());});
