(function(){'use strict';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function api(path,opts){const r=await fetch(path,{credentials:'same-origin',cache:'no-store',...opts});const text=await r.text();let j;try{j=JSON.parse(text)}catch{j={ok:false,error:`HTTP ${r.status}`}}if(!r.ok){const e=new Error(j.error||`HTTP ${r.status}`);e.status=r.status;e.agentOs=true;throw e}return j}
  function render(data){
    const target=document.querySelector('#dashboard')||document.querySelector('.dashboard')||document.querySelector('main'); if(!target)return;
    let panel=document.getElementById('sbcAgentOSPanel');
    if(!panel){panel=document.createElement('section');panel.id='sbcAgentOSPanel';panel.className='sbc-agent-os-panel';target.prepend(panel)}
    const m=data.metrics||{}; const gov=data.governor||{};
    const brainHtml=(data.brains||[]).map(b=>`<div class="sbc-agent-brain"><b>${esc(b.name)}</b><span>${esc(b.domain)}</span><i>READY</i></div>`).join('');
    panel.innerHTML=`<div class="sbc-agent-os-head"><div><div class="sbc-agent-kicker">SBC AGENT OPERATING SYSTEM</div><h2>10-Brain Intelligence + Agent Control Plane</h2><p>Unified Command Center. Durable MySQL state. Scoped agents. Owner-governed economics.</p></div><div class="sbc-agent-governor"><strong>$${Number(gov.threshold||10000).toLocaleString()}</strong><span>HARD OWNER FIREWALL</span></div></div>
      <div class="sbc-agent-metrics"><div><b>${m.events?.pending||0}</b><span>Queued Events</span></div><div><b>${m.jobs?.queued||0}</b><span>Queued Jobs</span></div><div><b>${m.governorHolds?.frozen||0}</b><span>Frozen Holds</span></div><div><b>${m.agents?.ready||0}</b><span>Ready Nodes</span></div></div>
      <div class="sbc-agent-brains-grid">${brainHtml}</div>
      <div class="sbc-agent-os-foot"><span>Release identity ${esc(data.version||'65.1.13')}</span><button type="button" id="sbcAgentOSRefresh">Refresh Intelligence</button><button type="button" id="sbcAgentOSHolds">Owner Holds</button></div>`;
    document.getElementById('sbcAgentOSRefresh')?.addEventListener('click',load);
    document.getElementById('sbcAgentOSHolds')?.addEventListener('click',async()=>{try{const x=await api('/api/agent-os/holds');alert(x.holds?.length?`${x.holds.length} frozen economic hold(s) require owner approval.`:'No frozen economic holds.');}catch(e){alert(e.message)}});
  }
  async function load(){try{const d=await api('/api/agent-os/status');render(d);return true}catch(e){
    const target=document.querySelector('#dashboard')||document.querySelector('.dashboard')||document.querySelector('main');
    if(target){let panel=document.getElementById('sbcAgentOSPanel');if(!panel){panel=document.createElement('section');panel.id='sbcAgentOSPanel';panel.className='sbc-agent-os-panel';target.prepend(panel)}
      panel.innerHTML='<div class="sbc-agent-os-head"><div><div class="sbc-agent-kicker">SBC AGENT OPERATING SYSTEM</div><h2>Agent Control Plane</h2><p>Intelligence service is temporarily unavailable. Command Center UI remains operational.</p></div><div class="sbc-agent-governor"><strong>OWNER</strong><span>CONTROLLED</span></div></div><div class="sbc-agent-os-foot"><span>UI release 65.1.13</span><button type="button" id="sbcAgentOSRetry">Retry</button></div>';
      document.getElementById('sbcAgentOSRetry')?.addEventListener('click',load);
    }
    return false;
  }}
  window.sbcAgentOSRefresh=load;
  document.addEventListener('DOMContentLoaded',()=>setTimeout(load,1200));
  setInterval(()=>{if(document.visibilityState==='visible')load()},60000);
})();
