/* SBC Business Command Center V11 — Final Workforce Edition */
(function(){
  const E=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const M=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(n||0));
  const role=()=>state.me?.role||'owner';
  const d=()=>state.data||{};
  const roleName={owner:'Owner / Admin',caller:'Sales Caller',lead_researcher:'Lead Researcher',fulfillment:'Fulfillment Specialist',manager:'Manager'};
  const requiredTraining=()=> (d().training||[]).filter(m=>m.role==='all'||m.role===role());
  const progress=()=>d().trainingProgress||{};
  const shell=(title,eyebrow,body)=>`<div class="crm-toolbar"><div><strong>${E(title)}</strong><span>${E(eyebrow)}</span></div></div>${body}`;
  const card=(title,body,badge='V10')=>`<div class="card section"><div class="card-head"><h2>${E(title)}</h2><span class="badge blue">${E(badge)}</span></div><div class="card-body">${body}</div></div>`;
  const queueBadge=n=>`<span class="badge ${Number(n)>0?'orange':'green'}">${Number(n)||0}</span>`;

  function nav(){
    const n=document.querySelector('.sidebar nav'); if(!n)return;
    const items=[['workforce','👥','Workforce'],['onboarding','🧾','Onboarding'],['training','🎓','Training Center'],['timeclock','⏱','Time Clock'],['leadresearch','🔎','Lead Research'],['callcenter','☎','Sales / Calling'],['fulfillment','💻','Fulfillment'],['catalog','◇','Master Price Book'],['payroll','💰','Payroll Center'],['metrics','📈','Performance Metrics'],['production','🎯','My Production']];
    items.forEach(([v,i,l])=>{if(!n.querySelector(`[data-view="${v}"]`)){const b=document.createElement('button');b.className='nav-item';b.dataset.view=v;b.innerHTML=`<span>${i}</span> ${l}`;n.appendChild(b)}});
  }
  function can(v){const r=role();return ({workforce:r==='owner',onboarding:['owner','caller','lead_researcher','fulfillment','manager'].includes(r),training:true,timeclock:true,leadresearch:['owner','manager','lead_researcher'].includes(r),callcenter:['owner','manager','caller'].includes(r),fulfillment:['owner','manager','fulfillment'].includes(r),catalog:true,payroll:['owner','manager'].includes(r),metrics:['owner','manager'].includes(r),production:true})[v]!==false}

  function dashboard(){
    const q=d().workQueues||{}, r=role();
    if(r==='lead_researcher') return shell('Lead Research Desk','WORKFORCE · LEAD GENERATION',`<div class="grid stats section"><div class="stat"><div class="label">LEADS NEEDING RESEARCH</div><div class="value">${q.leadResearch?.total||0}</div><div class="sub">Clean, qualified opportunities</div></div><div class="stat"><div class="label">CRM LEADS</div><div class="value">${d().customers?.length||0}</div><div class="sub">Available to research / enrich</div></div></div><div class="grid two">${card('Your Job','<ul class="feature-list"><li>Find real local businesses.</li><li>Verify business name, phone, industry and website status.</li><li>Avoid duplicates and bad data.</li><li>Submit clean leads into the SBC CRM.</li></ul>','RESEARCH')} ${card('Next Step','<p>Once a lead is submitted, the sales team can qualify and work it. You do not need access to pricing, payments or owner settings.</p><button class="btn primary" onclick="state.view=\'leadresearch\';render()">Open Lead Research</button>','HANDOFF')}</div>`);
    if(r==='fulfillment') return shell('Fulfillment Desk','WORKFORCE · CUSTOMER DELIVERY',`<div class="grid stats section"><div class="stat"><div class="label">ORDERS IN QUEUE</div><div class="value">${q.fulfillment?.orders||0}</div><div class="sub">New / quoted / in progress</div></div><div class="stat"><div class="label">PAID / ACTIVE</div><div class="value">${q.fulfillment?.paid||0}</div><div class="sub">Customer work to deliver</div></div></div><div class="grid two">${card('Fulfillment Workflow','<div class="list-card"><div><strong>Paid order → Requirements → Build → QC → Delivery</strong><div class="meta">Every handoff stays inside the Command Center.</div></div><button class="btn primary" onclick="state.view=\'fulfillment\';render()">Open Queue</button></div>','DELIVERY')} ${card('Website Production','<ul class="feature-list"><li>Build websites using SBC standards.</li><li>Handle domain, hosting and email setup.</li><li>Track customer revisions.</li><li>Complete launch/QC before delivery.</li></ul>','WEBSITES')}</div>`);
    return shell('SBC Command Center','V11 FINAL WORKFORCE EDITION · SALES → FULFILLMENT',`<div class="grid stats section"><div class="stat"><div class="label">TOTAL LEADS</div><div class="value">${d().customers?.length||0}</div><div class="sub">CRM records</div></div><div class="stat"><div class="label">SALES QUEUE</div><div class="value">${q.sales?.ready||0}</div><div class="sub">Leads ready to work</div></div><div class="stat"><div class="label">FULFILLMENT</div><div class="value">${q.fulfillment?.orders||0}</div><div class="sub">Orders in production</div></div><div class="stat"><div class="label">TEAM</div><div class="value">${(d().users||[]).filter(u=>u.role!=='owner').length}</div><div class="sub">Workforce accounts</div></div></div><div class="grid three section"><div class="card"><div class="card-body"><strong>🔎 Lead Research</strong><p class="mini">Find → qualify → submit.</p><button class="btn small" onclick="state.view='leadresearch';render()">Open</button></div></div><div class="card"><div class="card-body"><strong>☎ Sales</strong><p class="mini">Call → qualify → quote → close.</p><button class="btn small" onclick="state.view='callcenter';render()">Open</button></div></div><div class="card"><div class="card-body"><strong>💻 Fulfillment</strong><p class="mini">Paid → build → QC → deliver.</p><button class="btn small" onclick="state.view='fulfillment';render()">Open</button></div></div></div><div class="grid two">${card('SBC Operating Model','<p><strong>Flea Market Office = physical hub.</strong> Most prospecting, sales and production can happen remotely through the Command Center.</p><p class="mini">The system is designed so you are the owner/manager—not the bottleneck.</p>','MODEL')} ${card('Master Price Book','<p>One source of truth for packages and à-la-carte pricing. Square links can be attached later as each item is finalized.</p><button class="btn primary" onclick="state.view=\'catalog\';render()">Open Pricing</button>','PRICING')}</div>`);
  }

  function workforce(){
    const users=(d().users||[]).filter(u=>u.role!=='owner');
    return shell('Workforce Center','OWNER ONLY · ROLE-BASED ACCESS',`<div class="actions"><button class="btn primary" onclick="addWorker11()">+ Add Team Member</button></div>${card('Team Roster',users.map(u=>`<div class="list-card"><div><strong>${E(u.name)}</strong><div class="meta">${E(u.username)} · ${E(roleName[u.role]||u.role)} · ${u.active?'Active':'Disabled'}</div><div class="mini">${u.certified?'CERTIFIED':'Training not yet certified'}${u.expiresAt?' · expires '+E(u.expiresAt):''}</div>${u.profile?.title?`<div class="mini"><strong>${E(u.profile.title)}</strong> · ${E(u.profile.experience||'')}</div>`:''}</div><div class="actions" style="margin:0"><span class="badge ${u.active?'green':'red'}">${u.active?'ACTIVE':'DISABLED'}</span><button class="btn small" onclick="editWorker11('${u.id}')">Manage</button></div></div>`).join('')||'<div class="empty">No team members yet. Your first hires can be added here.</div>','RBAC')}<div class="grid three section"><div class="card"><div class="card-body"><strong>🔎 Lead Researcher</strong><p class="mini">Lead discovery, verification and submission.</p></div></div><div class="card"><div class="card-body"><strong>☎ Sales Caller</strong><p class="mini">Assigned leads, calls, follow-ups and sales reports.</p></div></div><div class="card"><div class="card-body"><strong>💻 Fulfillment</strong><p class="mini">Paid orders, websites, print and customer delivery.</p></div></div></div>`);
  }

  function addWorker11(existing){
    const u=existing||{};openModal(existing?'Manage Team Member':'Add SBC Team Member',`<form id="worker11"><div class="form-grid"><label>Full name<input name="name" value="${E(u.name)}" required></label><label>Username<input name="username" value="${E(u.username)}" ${existing?'disabled':''} required></label><label>Role<select name="role"><option value="lead_researcher" ${u.role==='lead_researcher'?'selected':''}>Lead Researcher</option><option value="caller" ${u.role==='caller'?'selected':''}>Sales Caller</option><option value="fulfillment" ${u.role==='fulfillment'?'selected':''}>Fulfillment Specialist</option><option value="manager" ${u.role==='manager'?'selected':''}>Manager</option></select></label><label>Password ${existing?'(leave blank to keep)':''}<input name="password" type="password" minlength="10" placeholder="${existing?'Leave blank to keep password':'At least 10 characters'}"></label><label>Expiration date<input name="expiresAt" type="date" value="${E(u.expiresAt||'')}"></label></div><div class="install-tip">🔐 Individual login. Never share the SBC owner password. Role permissions are enforced by the server.</div><div class="actions"><button type="button" class="btn" onclick="closeModal()">Cancel</button><button class="btn primary">${existing?'Save Changes':'Create Team Member'}</button></div></form>`);
    $('#worker11').onsubmit=async e=>{e.preventDefault();const x=Object.fromEntries(new FormData(e.target).entries());try{if(existing)await api('/api/users/'+existing.id,{method:'PUT',body:JSON.stringify(x)});else await api('/api/users',{method:'POST',body:JSON.stringify(x)});closeModal();await reload11();toast(existing?'Team member updated':'Team member created')}catch(err){toast(err.message)}};
  }
  function editWorker11(id){const u=(d().users||[]).find(x=>x.id===id);if(u)addWorker11(u)}

  let leadDraftTimer11=null;
  async function restoreLeadDraft11(){
    const form=$('#research11'); if(!form)return;
    try{
      const out=await api('/api/workforce/lead-draft');
      const draft=out?.draft;
      if(!draft)return;
      const hasTyped=[...form.elements].some(x=>x.name&&String(x.value||'').trim());
      if(hasTyped)return;
      for(const [k,v] of Object.entries(draft)){
        const el=form.elements[k]; if(!el)continue;
        if(el.type==='checkbox')el.checked=Boolean(v); else el.value=String(v??'');
      }
      const status=$('#research11Status');
      if(status)status.textContent='↻ Saved draft restored. Your work is persistent.';
    }catch(e){console.warn('[SBC LEAD] draft restore:',e.message)}
  }
  function scheduleLeadDraft11(form){
    clearTimeout(leadDraftTimer11);
    leadDraftTimer11=setTimeout(async()=>{
      try{
        const payload=Object.fromEntries(new FormData(form).entries());
        await api('/api/workforce/lead-draft',{method:'PUT',body:JSON.stringify(payload),timeoutMs:10000});
        const status=$('#research11Status');
        if(status&&!form.dataset.saving)status.textContent='✓ Draft saved automatically. You can leave and come back without re-entering it.';
      }catch(e){console.warn('[SBC LEAD] draft save:',e.message)}
    },700);
  }
  function editLeadResearch(id){
    const c=(d().customers||[]).find(x=>String(x.id)===String(id)); if(!c)return;
    const li={leadTemperature:'Cold',opportunityType:'Unclassified',bookingPlatform:'',verificationStatus:'Unverified',salesReady:false,verificationNotes:'',recommendedPackage:'',outreachStatus:'Not Contacted',lastContacted:'',nextFollowUp:'',assignedRep:'',revenuePlayStatus:'Held',estimatedDealValue:0,customerStatus:'Prospect',decisionMakerVerified:false,...(c.leadIntelligence||{})};
    openModal('Lead Intelligence',`<form id="leadEdit11"><div class="form-grid">
      <label>Business name<input name="businessName" value="${E(c.businessName||'')}"></label>
      <label>Contact name<input name="contactName" value="${E(c.contactName||'')}"></label>
      <label>Phone<input name="phone" value="${E(c.phone||'')}"></label>
      <label>Email<input name="email" value="${E(c.email||'')}"></label>
      <label>Website<input name="website" value="${E(c.website||'')}"></label>
      <label>Industry<input name="industry" value="${E(c.industry||'')}"></label>
      <label>Website Status<select name="websiteStatus">${['No Website','Has Website','Needs Review','Broken','Suspicious','Unknown'].map(x=>`<option ${x===c.websiteStatus?'selected':''}>${x}</option>`).join('')}</select></label>
      <label>Opportunity Type<select name="opportunityType">${['Unclassified','Website','Website Replacement','Hosting','Full Package'].map(x=>`<option ${x===li.opportunityType?'selected':''}>${x}</option>`).join('')}</select></label>
      <label>Booking Platform<input name="bookingPlatform" value="${E(li.bookingPlatform||'')}" placeholder="Squire / Booksy / Square / Vagaro"></label>
      <label>Lead Temperature<select name="leadTemperature">${['Cold','Warm','Hot'].map(x=>`<option ${x===li.leadTemperature?'selected':''}>${x}</option>`).join('')}</select></label>
      <label>Verification Status<select name="verificationStatus">${['Unverified','Pending','Verified','Owner Review','Rejected','Sales Ready'].map(x=>`<option ${x===li.verificationStatus?'selected':''}>${x}</option>`).join('')}</select></label>
      <label>Recommended SBC Package<input name="recommendedPackage" value="${E(li.recommendedPackage||'')}"></label>
      <label>Estimated Deal Value<input name="estimatedDealValue" type="number" min="0" step="1" value="${Number(li.estimatedDealValue||0)}"></label>
      <label>Outreach Status<select name="outreachStatus">${['Not Contacted','Attempted','Connected','Interested','Follow-up','Closed'].map(x=>`<option ${x===li.outreachStatus?'selected':''}>${x}</option>`).join('')}</select></label>
      <label>Revenue PLAY Status<select name="revenuePlayStatus">${['Held','Eligible','Played','Converted'].map(x=>`<option ${x===li.revenuePlayStatus?'selected':''}>${x}</option>`).join('')}</select></label>
      <label style="display:flex;gap:8px;align-items:center"><input name="decisionMakerVerified" type="checkbox" ${li.decisionMakerVerified?'checked':''}> Decision maker verified</label>
      <label style="display:flex;gap:8px;align-items:center"><input name="salesReady" type="checkbox" ${li.salesReady?'checked':''}> Sales Ready</label>
      <label style="grid-column:1/-1">Jonathan's Verification / Notes<textarea name="verificationNotes" rows="4">${E(li.verificationNotes||'')}</textarea></label>
      <label style="grid-column:1/-1">Research Notes<textarea name="notes" rows="4">${E(c.notes||'')}</textarea></label>
    </div><div class="actions"><button type="button" class="btn" onclick="closeModal()">Cancel</button><button class="btn primary">Save Lead Record</button></div></form>`);
    $('#leadEdit11').onsubmit=async e=>{
      e.preventDefault();const f=e.target,x=Object.fromEntries(new FormData(f).entries());
      x.leadIntelligence={opportunityType:x.opportunityType,bookingPlatform:x.bookingPlatform,leadTemperature:x.leadTemperature,verificationStatus:x.verificationStatus,salesReady:f.elements.salesReady.checked,verificationNotes:x.verificationNotes,recommendedPackage:x.recommendedPackage,outreachStatus:x.outreachStatus,revenuePlayStatus:x.revenuePlayStatus,estimatedDealValue:Number(x.estimatedDealValue||0),decisionMakerVerified:f.elements.decisionMakerVerified.checked};
      delete x.opportunityType;delete x.bookingPlatform;delete x.leadTemperature;delete x.verificationStatus;delete x.salesReady;delete x.verificationNotes;delete x.recommendedPackage;delete x.outreachStatus;delete x.revenuePlayStatus;delete x.estimatedDealValue;delete x.decisionMakerVerified;
      try{await api('/api/workforce/leads/'+encodeURIComponent(id),{method:'PUT',body:JSON.stringify(x)});closeModal();await reload11();toast('Lead record updated and saved permanently')}catch(err){toast(err.message)}
    };
  }
  window.editLeadResearch=editLeadResearch;
  function leadResearch(){
    const rows=(d().customers||[]).slice(0,250);
    const recoveryRows=(d().recoveryProjection||[]).slice(0,250); const pendingRecoveryRows=recoveryRows.filter(x=>!x._restored);
    const leadRows=rows.filter(x=>String(x.source||'').toLowerCase().includes('lorna')||x.researcherId);
    const recoveryNotice=pendingRecoveryRows.length?`<div class="card" style="margin-bottom:14px;border-color:rgba(34,197,94,.35)"><div class="card-body"><strong>🛡 ${pendingRecoveryRows.length} verified lead records still awaiting CRM restoration</strong><p class="mini">These are the real records held in <b>sbc_lead_mesh</b>. They are not being discarded. Owner-controlled restoration places them into the authoritative CRM with deterministic IDs and preserves the lead-mesh source reference. Full CRM recovery remains protected until the rest of the authoritative core is restored.</p><div class="actions" style="margin-top:10px"><button class="btn primary" type="button" onclick="window.sbcRestoreVerifiedLeads?.()">Restore Verified Leads to CRM</button></div></div></div>`:'';
    return shell('Lead Research Desk','FIND → QUALIFY → VERIFY → REVENUE PLAY',
      recoveryNotice+`<div class="grid stats section">
        <div class="stat"><div class="label">AUTHORITATIVE CRM LEADS</div><div class="value">${rows.length}</div><div class="sub">Persistent central CRM</div></div>
        <div class="stat"><div class="label">RECOVERY LEAD CANDIDATES</div><div class="value">${pendingRecoveryRows.length}</div><div class="sub">Verified source records not yet restored</div></div>
        <div class="stat"><div class="label">READY FOR VERIFICATION</div><div class="value">${rows.filter(x=>String(x.leadIntelligence?.verificationStatus||'Unverified')!=='Verified').length}</div><div class="sub">Jonathan review queue</div></div>
      </div>
      ${card('Submit a New Qualified Lead',`<form id="research11"><div class="form-grid">
        <label>Business name *<input name="businessName" required></label><label>Phone<input name="phone"></label>
        <label>Email<input name="email" type="email"></label><label>Website<input name="website" placeholder="https://"></label>
        <label>Industry<input name="industry"></label><label>Website status<select name="websiteStatus"><option>No Website</option><option>Has Website</option><option>Needs Review</option><option>Broken</option><option>Suspicious</option></select></label>
        <label>Contact name<input name="contactName"></label><label>Source<input name="source" value="Lorna — Lead Research"></label>
        <label style="grid-column:1/-1">Research notes<textarea name="notes" placeholder="Why this business is a good SBC prospect"></textarea></label>
      </div><div id="research11Status" class="mini" style="margin:10px 0;min-height:20px">Your draft saves automatically while you work.</div><div class="actions"><button id="research11Submit" class="btn primary" type="submit">Save Lead to CRM</button></div></form>`,'QUALIFIED LEAD')}
      ${card('Persistent Lead Intelligence',rows.slice(0,40).map(c=>{
        const li=c.leadIntelligence||{};const temp=li.leadTemperature||'Cold';const v=li.verificationStatus||'Unverified';
        return `<div class="list-card"><div><strong>${E(c.businessName||c.phone||'Unnamed')}</strong><div class="meta">${E(c.industry||'—')} · ${E(c.phone||'—')} · ${E(c.websiteStatus||'—')} · ${E(li.bookingPlatform||'No booking platform recorded')}</div><div class="mini">${E(li.opportunityType||'Unclassified')} · ${E(temp)} · ${E(v)} · ${li.salesReady?'SALES READY':'Not Sales Ready'}</div></div><div class="actions" style="margin:0"><span class="badge ${temp==='Hot'?'red':temp==='Warm'?'orange':'blue'}">${E(temp)}</span><button class="btn small" onclick="editLeadResearch('${E(c.id)}')">Edit</button></div></div>`;
      }).join('')||'<div class="empty">No CRM records yet.</div>','PERSISTENT CRM')}`);
    const form=$('#research11');
    if(form){
      form.addEventListener('input',()=>scheduleLeadDraft11(form));
      form.addEventListener('change',()=>scheduleLeadDraft11(form));
      form.addEventListener('submit',async e=>{
        e.preventDefault();form.dataset.saving='1';const btn=form.querySelector('#research11Submit'),status=$('#research11Status');
        if(btn){btn.disabled=true;btn.textContent='Saving Lead…'}if(status)status.textContent='Saving to the central SBC CRM…';
        try{
          const created=await api('/api/workforce/leads',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(form).entries()))});
          await api('/api/workforce/lead-draft',{method:'DELETE'}).catch(()=>{});
          if(status)status.textContent=`✓ Lead saved permanently · ${created.businessName||created.phone||created.id}`;
          form.reset();if(form.elements.source)form.elements.source.value='Lorna — Lead Research';
          try{await reload11();}catch(refr){console.warn('[SBC LEAD] refresh after save:',refr);}
          toast('Lead saved to the central SBC CRM');
        }catch(err){if(status)status.textContent=`Save failed: ${err?.message||'Unknown error'}`;toast(err?.message||'Lead could not be saved')}
        finally{delete form.dataset.saving;if(btn){btn.disabled=false;btn.textContent='Save Lead to CRM'}}
      });
      restoreLeadDraft11();
    }
  }

  function fulfillment(){
    const orders=d().orders||[];const users=(d().users||[]).filter(u=>u.role==='fulfillment');return shell('Fulfillment Center','PAID ORDER → PRODUCTION → QC → DELIVERY',`${card('Fulfillment Queue',orders.map(o=>`<div class="list-card"><div><strong>${E(o.customerName||o.customer||'Customer')}</strong><div class="meta">${E(o.product||o.description||'Order')} · Qty ${E(o.quantity||1)} · ${E(o.status||'New')}</div><div class="mini">Price ${M(o.price||0)} · ${o.fulfillmentOwnerName?'Assigned to '+E(o.fulfillmentOwnerName):'Unassigned'}</div></div><div class="actions" style="margin:0"><span class="badge ${['Delivered','Ready'].includes(o.status)?'green':'orange'}">${E(o.status||'New')}</span>${role()==='owner'||role()==='manager'?`<button class="btn small" onclick="assignOrder11('${o.id}')">Assign</button>`:''}<button class="btn small primary" onclick="openOrder11('${o.id}')">Open</button></div></div>`).join('')||'<div class="empty">No fulfillment orders yet.</div>','CUSTOMER DELIVERY')}<div class="grid three section"><div class="card"><div class="card-body"><strong>1. Requirements</strong><p class="mini">Confirm pages, content, domain, email, print and customer preferences.</p></div></div><div class="card"><div class="card-body"><strong>2. Production</strong><p class="mini">Build website, configure services and submit print orders.</p></div></div><div class="card"><div class="card-body"><strong>3. QC + Delivery</strong><p class="mini">Check links, mobile view, branding, spelling and final customer approval.</p></div></div></div>`);
  }
  function assignOrder11(id){const us=(d().users||[]).filter(u=>u.role==='owner');openModal('Assign Fulfillment Order',`<label>Fulfillment Owner<select id="assignWorker10"><option value="">Unassigned</option>${us.map(u=>`<option value="${E(u.id)}">${E(u.name)} — Owner / Fulfillment</option>`).join('')}</select></label><div class="install-tip" style="margin-top:10px">🔒 Romeo is the only SBC fulfillment operator.</div><div class="actions"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="saveOrderAssignment11('${id}')">Assign</button></div>`)}
  async function saveOrderAssignment11(id){try{await api('/api/v10/orders/'+id+'/assign',{method:'POST',body:JSON.stringify({userId:$('#assignWorker10').value})});closeModal();await reload11();toast('Fulfillment assignment saved')}catch(e){toast(e.message)}}
  function openOrder11(id){const o=(d().orders||[]).find(x=>x.id===id);if(!o)return;openModal('Fulfillment Order',`<div class="list-card"><div><strong>${E(o.customerName||'Customer')}</strong><div class="meta">${E(o.product||'Order')} · ${E(o.status||'New')}</div></div><span class="badge orange">${E(o.status||'New')}</span></div><div class="grid two" style="margin-top:14px"><label>Status<select id="foStatus11">${['New','Quoted','In Progress','Ready','Delivered','Cancelled'].map(s=>`<option ${o.status===s?'selected':''}>${s}</option>`).join('')}</select></label><label>Customer price<input id="foPrice11" type="number" value="${Number(o.price||0)}"></label></div><label style="margin-top:12px">Requirements / notes<textarea id="foNotes11">${E(o.notes||'')}</textarea></label><div class="actions"><button class="btn" onclick="closeModal()">Close</button><button class="btn primary" onclick="saveOrder11('${id}')">Save Fulfillment Update</button></div>`)}
  async function saveOrder11(id){try{await api('/api/orders/'+id,{method:'PUT',body:JSON.stringify({status:$('#foStatus11').value,price:Number($('#foPrice11').value||0),notes:$('#foNotes11').value})});closeModal();await reload11();toast('Fulfillment order updated')}catch(e){toast(e.message)}}

  function openTrainingModule11(id){ if(window.openTrainingModuleV2){ window.openTrainingModuleV2('',id); } else if(window.loadTrainingCenterV2){ window.loadTrainingCenterV2(); } }
  function training(){ return window.trainingV2View ? window.trainingV2View() : '<div class="card section"><div class="card-body">Training Center is loading…</div></div>'; }
  function manageTraining11(id){ if(window.trainingEmployeeHistoryV2) return window.trainingEmployeeHistoryV2(id); }
  async function resetTraining11(id){ try{ await api('/api/training/certification/'+encodeURIComponent(id),{method:'POST',body:JSON.stringify({status:'Not Certified',reason:'Owner reset'})}); if(window.loadTrainingCenterV2)await window.loadTrainingCenterV2(); toast('Training certification reset'); }catch(e){toast(e.message)} }
  function onboarding11(){
    const r=role(), owner=r==='owner', roster=d().onboardingRoster||[];
    if(owner){
      return shell('Contractor Onboarding','WORKFORCE · ROLE · IDENTITY · AGREEMENTS · OWNER APPROVAL',`<div class="card section"><div class="card-head"><div><h2>Team Onboarding Roster</h2><div class="mini">Every new team member is assigned a role first. Onboarding and training run independently; production access remains separately controlled.</div></div><button class="btn primary" onclick="addWorker11()">+ Add Team Member</button></div><div class="card-body">${roster.map(x=>{const u=x.user||{},o=x.onboarding||{};return `<div class="list-card"><div><strong>${E(u.name||'Team Member')}</strong><div class="meta">${E(roleName[u.role]||u.role||'Unassigned')} · ${E(u.username||'')}</div><div class="mini">${E(o.legalName||'Legal name not entered')} · ${E(o.country||'Country not entered')} · ${E(o.timezone||'Timezone not entered')}</div></div><div class="actions" style="margin:0"><span class="badge ${o.status==='Approved'?'green':o.status==='Pending Owner Verification'?'orange':'purple'}">${E(o.status||'Not Started')}</span><button class="btn small primary" onclick="manageOnboarding11('${E(u.id)}')">Review</button></div></div>`}).join('')||'<div class="empty">No team members yet. Add your first researcher, caller or fulfillment specialist above.</div>'}</div></div>`);
    }
    const o=d().onboarding||{}, approved=o.status==='Approved';
    return shell('Contractor Onboarding',`${E(roleName[r]||r)} · ONBOARDING & TRAINING RUN IN PARALLEL`, `<div class="grid stats section"><div class="stat"><div class="label">ASSIGNED ROLE</div><div class="value" style="font-size:18px">${E(roleName[r]||r)}</div><div class="sub">Your SBC position</div></div><div class="stat"><div class="label">STATUS</div><div class="value" style="font-size:18px">${E(o.status||'Incomplete')}</div><div class="sub">Owner approval required</div></div><div class="stat"><div class="label">TRAINING</div><div class="value" style="font-size:18px">${d().user?.active===false?'UNAVAILABLE':'UNLOCKED'}</div><div class="sub">Training is available immediately</div></div></div><div class="card section"><div class="card-head"><h2>Contractor Profile & Agreements</h2><span class="badge ${approved?'green':'orange'}">${approved?'APPROVED':'REQUIRED'}</span></div><div class="card-body"><div class="install-tip">🔒 Do not enter a full bank/card number. Use payment method + last 4 only.</div><form id="onboard11"><div class="form-grid"><label>Legal name *<input name="legalName" value="${E(o.legalName)}"></label><label>Preferred name<input name="preferredName" value="${E(o.preferredName)}"></label><label>Email *<input type="email" name="email" value="${E(o.email)}"></label><label>Phone *<input name="phone" value="${E(o.phone)}"></label><label>Street address *<input name="address" value="${E(o.address)}"></label><label>City *<input name="city" value="${E(o.city)}"></label><label>Region / Province<input name="region" value="${E(o.region)}"></label><label>Postal code<input name="postalCode" value="${E(o.postalCode)}"></label><label>Country *<input name="country" value="${E(o.country||'Philippines')}"></label><label>Time zone *<input name="timezone" value="${E(o.timezone)}" placeholder="Asia/Manila"></label><label>Remote work location *<input name="remoteLocation" value="${E(o.remoteLocation)}"></label><label>Payment method *<input name="paymentMethod" value="${E(o.paymentMethod)}" placeholder="Wise / PayPal / Payoneer / bank"></label><label>Payment account last 4<input name="paymentAccountLast4" value="${E(o.paymentAccountLast4)}" maxlength="4"></label><label>Tax form status<select name="taxFormStatus"><option ${o.taxFormStatus==='Pending'?'selected':''}>Pending</option><option ${o.taxFormStatus==='Received'?'selected':''}>Received</option><option ${o.taxFormStatus==='Reviewed'?'selected':''}>Reviewed</option></select></label><label>Government ID status<select name="governmentIdStatus"><option ${o.governmentIdStatus==='Pending'?'selected':''}>Pending</option><option ${o.governmentIdStatus==='Received'?'selected':''}>Received</option><option ${o.governmentIdStatus==='Reviewed'?'selected':''}>Reviewed</option></select></label></div><div class="card" style="margin-top:14px"><div class="card-body"><h3>Required acknowledgments</h3><label class="check-row"><input type="checkbox" name="contractorAgreementAccepted" ${o.contractorAgreementAccepted?'checked':''}> I accept the SBC Independent Contractor Agreement.</label><label class="check-row"><input type="checkbox" name="confidentialityAccepted" ${o.confidentialityAccepted?'checked':''}> I agree to keep SBC/customer information confidential.</label><label class="check-row"><input type="checkbox" name="codeOfConductAccepted" ${o.codeOfConductAccepted?'checked':''}> I agree to the SBC Code of Conduct.</label><label class="check-row"><input type="checkbox" name="remoteLocationConfirmed" ${o.remoteLocationConfirmed?'checked':''}> I confirm remote work from the location listed above.</label></div></div><label>Notes / questions<textarea name="notes">${E(o.notes||'')}</textarea></label><div class="actions"><button class="btn primary">Save Onboarding</button></div></form></div></div>`);
    const form=$('#onboard11'); if(form){form.setAttribute('novalidate',''); const btn=form.querySelector('button.btn.primary'); if(btn){btn.type='button';btn.textContent='Complete Onboarding';btn.onclick=()=>submitOnboarding11();} }
    async function submitOnboarding11(){const form=$('#onboard11');if(!form)return;const fd=new FormData(form),x=Object.fromEntries(fd.entries());for(const k of ['contractorAgreementAccepted','confidentialityAccepted','codeOfConductAccepted','remoteLocationConfirmed'])x[k]=fd.has(k);const btn=form.querySelector('button.btn.primary');if(btn){btn.disabled=true;btn.textContent='Saving…';}try{const saved=await api('/api/v9/onboarding/'+encodeURIComponent(state.me.id),{method:'PUT',body:JSON.stringify(x)});await reload11();toast(saved.status==='Pending Owner Verification'?'Onboarding submitted for Romeo’s verification':'Onboarding saved — finish the remaining items when ready.');}catch(err){toast(err.message)}finally{if(btn){btn.disabled=false;btn.textContent='Complete Onboarding';}}} 

  }
  function manageOnboarding11(uid){
    const r=(d().onboardingRoster||[]).find(x=>x.user?.id===uid),u=r?.user||{},o=r?.onboarding||{}; if(!r)return;
    openModal('Review Onboarding — '+E(u.name),`<div class="list-card"><div><strong>${E(roleName[u.role]||u.role)}</strong><div class="meta">${E(u.username||'')} · ${E(o.status||'Not Started')}</div></div><span class="badge ${o.status==='Approved'?'green':'orange'}">${E(o.status||'Not Started')}</span></div><div class="grid two" style="margin-top:14px"><div class="card"><div class="card-body"><strong>Identity</strong><div class="mini">${E(o.legalName||'—')}<br>${E(o.email||'—')} · ${E(o.phone||'—')}<br>${E(o.address||'—')}, ${E(o.city||'—')} ${E(o.region||'')}</div></div></div><div class="card"><div class="card-body"><strong>Remote / Payment</strong><div class="mini">Country: ${E(o.country||'—')}<br>Timezone: ${E(o.timezone||'—')}<br>Remote: ${E(o.remoteLocation||'—')}<br>Payment: ${E(o.paymentMethod||'—')} · ****${E(o.paymentAccountLast4||'')}</div></div></div></div><div class="card section"><div class="card-body"><strong>Documentation & acknowledgments</strong><div class="mini">Tax: ${E(o.taxFormStatus||'Pending')} · ID: ${E(o.governmentIdStatus||'Pending')}<br>Agreement: ${o.contractorAgreementAccepted?'✓':'✗'} · Confidentiality: ${o.confidentialityAccepted?'✓':'✗'} · Code: ${o.codeOfConductAccepted?'✓':'✗'} · Remote confirmed: ${o.remoteLocationConfirmed?'✓':'✗'}</div></div></div><div class="actions"><button class="btn" onclick="closeModal()">Close</button><button class="btn" onclick="reviewOnboarding11('${uid}',false)">Return for Completion</button><button class="btn primary" onclick="reviewOnboarding11('${uid}',true)">Approve Onboarding</button></div>`);
  }
  async function reviewOnboarding11(uid,approved){try{await api('/api/v9/onboarding/'+uid,{method:'PUT',body:JSON.stringify({ownerVerified:approved})});closeModal();await reload11();toast(approved?'Onboarding approved — training remains available':'Returned for completion')}catch(e){toast(e.message)}}
  async function metrics11(){
    if(!['owner','manager'].includes(role())) return shell('Performance Metrics','OWNER / MANAGER','<div class="empty">Performance metrics are restricted to owner/manager accounts.</div>');
    let m; try{m=await api('/api/v11/metrics')}catch(e){return shell('Performance Metrics','OWNER / MANAGER',`<div class="install-tip">⚠️ Unable to load metrics: ${E(e.message)}</div>`)}
    const emp=m.employees||[];
    const fmt=n=>Number(n||0).toFixed(1), pct=n=>Number(n||0).toFixed(0)+'%';
    const totals=period=>emp.reduce((a,u)=>{const x=u[period]||{};for(const k of ['hours','leads','qualified','calls','contacts','appointments','sales','orders','completedOrders'])a[k]=(a[k]||0)+(Number(x[k])||0);return a},{})
    const w=totals('week'), mo=totals('month');
    const score=x=>{if(!x)return 0;if(x.leads>0)return Math.min(100,Math.round((Math.min(x.qualificationRate,100)*.45)+(Math.min(x.leadsPerHour/8*100,100)*.25)+(Math.min((x.hours/20)*100,100)*.15)+((x.rejected===0?100:Math.max(0,100-x.rejected/Math.max(1,x.leads)*100))*.15)));if(x.calls>0)return Math.min(100,Math.round((Math.min(x.closeRate/20*100,100)*.5)+(Math.min(x.appointments/10*100,100)*.25)+(Math.min(x.hours/20*100,100)*.25)));if(x.orders>0)return Math.round((x.completionRate*.7)+(Math.min(x.completedOrders/10*100,100)*.3));return 0};
    const grade=s=>s>=90?'Excellent':s>=75?'Good':s>=60?'Watch':'Needs Improvement';
    const rows=emp.map(u=>{const x=u.month||{},s=score(x);return `<tr><td><strong>${E(u.name)}</strong><div class="mini">${E(roleName[u.role]||u.role)}</div></td><td>${fmt(x.hours)}h</td><td>${x.leads||0}</td><td>${x.qualified||0}</td><td>${x.calls||0}</td><td>${x.appointments||0}</td><td>${x.sales||0}</td><td>${x.orders||0}</td><td><span class="badge ${s>=75?'green':s>=60?'orange':'red'}">${s?`${s} · ${grade(s)}`:'No data'}</span></td></tr>`}).join('')||'<tr><td colspan="9" class="empty">No team members yet.</td></tr>';
    return shell('Performance Metrics','OWNER / MANAGER · PRODUCTION SCORECARD',`<div class="install-tip">📈 <strong>Measure output, quality and business impact.</strong> Metrics are calculated from Command Center activity, time entries, CRM lead handoffs, approved call reports and fulfillment orders. This is a work-production dashboard — not keystroke or screenshot surveillance.</div><div class="grid stats section"><div class="stat"><div class="label">TEAM HOURS · 7 DAYS</div><div class="value">${fmt(w.hours)}h</div><div class="sub">Tracked work time</div></div><div class="stat"><div class="label">LEADS · 7 DAYS</div><div class="value">${w.leads||0}</div><div class="sub">Research submissions</div></div><div class="stat"><div class="label">APPOINTMENTS · 7 DAYS</div><div class="value">${w.appointments||0}</div><div class="sub">Approved sales activity</div></div><div class="stat"><div class="label">SALES · 7 DAYS</div><div class="value">${w.sales||0}</div><div class="sub">Closed/won reports</div></div></div><div class="grid three section"><div class="card"><div class="card-body"><strong>📅 This Week</strong><p class="mini">${w.leads||0} leads · ${w.calls||0} calls · ${w.appointments||0} appointments · ${w.sales||0} sales</p></div></div><div class="card"><div class="card-body"><strong>📊 This Month</strong><p class="mini">${mo.leads||0} leads · ${mo.calls||0} calls · ${mo.appointments||0} appointments · ${mo.sales||0} sales</p></div></div><div class="card"><div class="card-body"><strong>📝 60-Day Review</strong><p class="mini">Use this period for compensation/performance reviews.</p></div></div></div><div class="card section"><div class="card-head"><h2>Team Production Scorecard</h2><span class="badge blue">30 DAYS</span></div><div class="card-body"><div class="table-wrap"><table class="table"><thead><tr><th>Team Member</th><th>Hours</th><th>Leads</th><th>Qualified</th><th>Calls</th><th>Appointments</th><th>Sales</th><th>Orders</th><th>Performance</th></tr></thead><tbody>${rows}</tbody></table></div></div></div><div class="grid two section">${emp.map(u=>{const x=u.review||{},s=score(x);return card(E(u.name),`<div class="grid two"><div><div class="label">HOURS</div><div class="value">${fmt(x.hours)}h</div></div><div><div class="label">LEADS</div><div class="value">${x.leads||0}</div></div><div><div class="label">QUALIFICATION</div><div class="value">${pct(x.qualificationRate)}</div></div><div><div class="label">LEADS / HOUR</div><div class="value">${fmt(x.leadsPerHour)}</div></div><div><div class="label">APPOINTMENTS</div><div class="value">${x.appointments||0}</div></div><div><div class="label">SALES</div><div class="value">${x.sales||0}</div></div></div><div class="install-tip" style="margin-top:14px">60-day score: <strong>${s||0}</strong> — ${grade(s)}. Use with manager judgment; do not treat the score as the sole basis for pay decisions.</div>`,'60-DAY REVIEW')}).join('')}</div>`);
  }


  function production(){
    const x=d().productionScoreboard||{}, m=x.me?.metrics||{}, g=x.me?.goals||{}, p=x.phase||{}, c=x.company||null;
    const pct=(a,b)=>b?Math.min(100,Math.round(Number(a||0)/Number(b)*100)):0;
    const goal=(label,val,target)=>`<div class="stat"><div class="label">${E(label)}</div><div class="value">${E(String(val??0))}</div><div class="sub">Goal ${E(String(target??0))} · ${pct(val,target)}%</div></div>`;
    if(role()==='owner'){
      const rows=(x.team||[]).map(t=>{const z=t.metrics||{},tg=t.goals||{};return `<tr><td><strong>${E(t.user?.name||'')}</strong><div class="mini">${E(t.user?.role||'')}</div></td><td>${z.leads||0}/${tg.leads||0}</td><td>${z.verified||0}</td><td>${z.sales||0}/${tg.sales||0}</td><td>${M(z.revenue||z.reportedRevenue||0)}</td><td>${z.recurring||0}</td><td>${fmtHours(z.hours||0)}</td></tr>`}).join('')||'<tr><td colspan=7 class="empty">No workforce production data yet.</td></tr>';
      return shell('SBC Production Control','OWNER · 60-DAY COMPANY DESTINATION',`<div class="grid stats section">${goal('NEW LEADS · 7D',c?.leads||0,x.goals?.weekly?.leadResearcherLeads||100)}${goal('RECURRING CUSTOMERS · 7D',c?.recurringCustomers||0,x.goals?.weekly?.recurringCustomers||3)}${goal('NEW MRR · 7D',M(c?.newMrr||0),M(x.goals?.weekly?.newMrr||597))}${goal('SALES · 7D',c?.sales||0,x.goals?.weekly?.salesClosed||3)}</div><div class="grid two section"><div class="card"><div class="card-body"><span class="badge blue">DAY ${x.dayOf60||0} / 60</span><h2 style="margin-top:10px">${E(p.name||'PROVE')}</h2><p>${E(p.focus||'')}</p><strong>Next staffing move:</strong> ${E(p.hire||'')}</div></div><div class="card"><div class="card-body"><strong>Destination</strong><div class="value">${M(x.goals?.destination?.weeklyNewMrr||2000)} / week</div><p class="mini">This is the operating target, not a guaranteed forecast. The system records actuals.</p></div></div></div><div class="card section"><div class="card-head"><h2>Team Production</h2><span class="badge blue">LIVE</span></div><div class="card-body table-wrap"><table class="table"><thead><tr><th>Team Member</th><th>Leads</th><th>Verified</th><th>Sales</th><th>Revenue</th><th>Recurring</th><th>Hours</th></tr></thead><tbody>${rows}</tbody></table></div></div>`);
    }
    const isLorna=role()==='lead_researcher';
    const leadTarget=g.leads||100;
    return shell('My Production','WORKFORCE · YOUR GOALS & SCOREBOARD',`<div class="install-tip">🎯 <strong>Your production scoreboard.</strong> SBC measures completed work and downstream business results. It does not use keystroke or screenshot surveillance.</div><div class="grid stats section">${goal(isLorna?'LEADS · THIS WEEK':'WORK ITEMS · THIS WEEK',m.leads||0,leadTarget)}${goal('VERIFIED',m.verified||0,Math.round(leadTarget*Number(g.verifiedRate||0.9)))}${goal(isLorna?'WARM / HOT':'SALES',isLorna?(m.warmHot||0):(m.sales||0),isLorna?Math.round(leadTarget*.25):(g.sales||3))}${goal('HOURS',fmtHours(m.hours||0),20)}</div><div class="grid two section"><div class="card"><div class="card-body"><span class="badge ${pct(m.leads,leadTarget)>=100?'green':'orange'}">${pct(m.leads,leadTarget)}% GOAL</span><h2 style="margin-top:10px">${E(p.name||'PRODUCTION')}</h2><p>${E(p.focus||'Keep the pipeline moving.')}</p><div class="mini">Week starting ${E(x.weekStarting||'')}</div></div></div><div class="card"><div class="card-body"><strong>Downstream impact</strong><p class="mini">Sales: ${m.sales||0} · Recurring orders: ${m.recurring||0} · Revenue: ${M(m.revenue||m.reportedRevenue||0)}</p><p class="mini">Your work is attributed through the existing CRM, sales reports, orders and time-clock rails.</p></div></div></div>`);
  }
  function fmtHours(n){return Number(n||0).toFixed(1)+'h'}

  function payroll11(){const canonical=window.sbcPayrollCenterV9;return typeof canonical==='function'?canonical():shell('Payroll Center','OWNER / MANAGER','<div class="empty">Payroll tools are available to owner/manager accounts.</div>')}

  function catalog11(){
    const cat=d().catalog||{packages:[],services:[]};
    const pkgCard=(p,i)=>`<div class="card price-card ${i===3?'featured':''}"><span class="badge ${i===3?'green':'blue'}">${i===3?'COMPLETE':E(p.category||'SBC PACKAGE')}</span><h3>${E(p.name)}</h3><div class="price">${M(p.price)}</div><p class="mini">${E(p.description)}</p><ul class="feature-list">${(p.features||[]).slice(0,8).map(f=>`<li>${E(f)}</li>`).join('')}</ul>${p.paymentUrl?`<a class="btn primary wide" href="${E(p.paymentUrl)}" target="_blank" rel="noopener">Square Checkout ↗</a>`:'<span class="badge orange">Square link pending</span>'}</div>`;
    const core=cat.packages.filter(p=>p.category==='Package'), stores=cat.packages.filter(p=>p.category==='E-Commerce');
    return shell('Master Price Book','SBC · ONE SOURCE OF TRUTH',`<div class="install-tip">💰 <strong>V11 customer-facing pricing.</strong> Package inclusions match the SBC website. Square links appear only where an approved link exists.</div><h2 style="margin:20px 0 10px">Core SBC Packages</h2><div class="grid four section">${core.map(pkgCard).join('')}</div><h2 style="margin:20px 0 10px">E-Commerce Packages</h2><div class="grid three section">${stores.map(pkgCard).join('')}</div><div class="table-wrap"><table class="table"><thead><tr><th>Service</th><th>Category</th><th>Price</th><th>Unit</th></tr></thead><tbody>${cat.services.map(s=>`<tr><td><strong>${E(s.name)}</strong></td><td>${E(s.category)}</td><td>${M(s.price)}</td><td>${E(s.unit||'service')}</td></tr>`).join('')}</tbody></table></div>`);
  }

  function users11(){return workforce()}
  function render11(){
    nav();
    const r=role();
    const names={dashboard:['COMMAND CENTER','Dashboard'],workforce:['WORKFORCE','Workforce'],onboarding:['WORKFORCE','Contractor Onboarding'],training:['TRAINING','Role Training Center'],timeclock:['WORKFORCE','Time Clock'],leadresearch:['LEAD GENERATION','Lead Research'],callcenter:['SALES','Sales / Calling'],fulfillment:['FULFILLMENT','Fulfillment Center'],catalog:['PRICING','Master Price Book'],payroll:['PAYROLL','Payroll Center'],metrics:['BUSINESS INTELLIGENCE','Performance Metrics'],production:['WORKFORCE','My Production'],customers:['CRM','Leads & Customers'],crm:['SALES','Sales CRM'],leadimport:['LEAD GENERATION','Lead Import'],quotes:['SALES','Quotes'],payments:['PAYMENTS','Payments'],orders:['FULFILLMENT','Print Orders'],renewals:['RECURRING REVENUE','Renewals'],followups:['NEXT ACTIONS','Follow-ups'],reports:['BUSINESS INTELLIGENCE','Reports'],presentation:['CUSTOMER MODE','Client Presentation'],communications:['COMMUNICATIONS','Email & SMS'],calendar:['SCHEDULING','Calendar'],tasks:['NEXT ACTIONS','Task Center'],settings:['CONTROL PANEL','Settings'],users:['SECURITY','Users & Security']};
    if(!can(state.view))state.view='dashboard';
    const f={dashboard,workforce,onboarding:onboarding11,training,timeclock:window.timeclock,leadresearch:leadResearch,callcenter:window.callcenter9,fulfillment,catalog:catalog11,payroll:payroll11,metrics:metrics11,production,customers:window.customers9,crm:window.crm,leadimport:window.leadimport,quotes:window.quotes,payments:window.payments,orders:window.orders,renewals:window.renewals,followups:window.followups,reports:window.reports,presentation:window.presentation,communications:window.communications,calendar:window.calendar,tasks:window.tasks,settings:window.settings,users:users11};
    let fn=f[state.view]||dashboard;
    if(typeof fn!=='function')fn=dashboard;
    const n=names[state.view]||names.dashboard;$('#viewEyebrow').textContent=n[0];$('#viewTitle').textContent=n[1];$('#content').innerHTML=fn();
    $$('.nav-item[data-view]').forEach(x=>{x.classList.toggle('active',x.dataset.view===state.view);const v=x.dataset.view;if(['workforce','onboarding','training','timeclock','leadresearch','callcenter','fulfillment','catalog','payroll','metrics','production'].includes(v))x.style.display=can(v)?'':'none';if(v==='users')x.style.display=r==='owner'?'':'none'});
    if(r==='caller'){['dashboard','onboarding','training','timeclock','callcenter','customers','catalog','production'].forEach(v=>{const x=$(`.nav-item[data-view="${v}"]`);if(x)x.style.display=''});['leadimport','quotes','payments','orders','settings','users','workforce','payroll','fulfillment','leadresearch'].forEach(v=>{const x=$(`.nav-item[data-view="${v}"]`);if(x)x.style.display='none'})}
    if(r==='lead_researcher'){['dashboard','onboarding','training','timeclock','leadresearch','customers','catalog','production'].forEach(v=>{const x=$(`.nav-item[data-view="${v}"]`);if(x)x.style.display=''});['quotes','payments','orders','settings','users','workforce','payroll','fulfillment','callcenter'].forEach(v=>{const x=$(`.nav-item[data-view="${v}"]`);if(x)x.style.display='none'})}
    if(r==='fulfillment'){['dashboard','onboarding','training','timeclock','fulfillment','catalog','production'].forEach(v=>{const x=$(`.nav-item[data-view="${v}"]`);if(x)x.style.display=''});['quotes','payments','leadimport','settings','users','workforce','payroll','callcenter','leadresearch'].forEach(v=>{const x=$(`.nav-item[data-view="${v}"]`);if(x)x.style.display='none'})}
  }
  async function reload11(){state.data=await api('/api/v9/bootstrap');state.catalog=state.data.catalog||state.catalog;try{state.data.productionScoreboard=await api('/api/workforce/production-scoreboard')}catch(e){state.data.productionScoreboard={ok:false,error:e.message}}render11()}
  window.reload11=reload11;window.reload10=reload11;
  // V55.10.1: expose V10 workforce/employee renderers to the canonical app.js router.
  // Without these globals, Workforce, Payroll, and Onboarding fall through to the
  // generic 'section unavailable' renderer even though the implementations exist.
  window.workforce=workforce;
  window.payrollCenter=payroll11;
  window.onboardingView=onboarding11;
  window.users11=users11;
  window.fulfillment=fulfillment;
  window.leadResearch=leadResearch; window.metrics11=metrics11;window.catalog11=catalog11;window.addWorker11=addWorker11;window.manageOnboarding11=manageOnboarding11;window.reviewOnboarding11=reviewOnboarding11;window.editWorker11=editWorker11;window.openTrainingModule11=openTrainingModule11;window.manageTraining11=manageTraining11;window.resetTraining11=resetTraining11;window.assignOrder11=assignOrder11;window.saveOrderAssignment11=saveOrderAssignment11;window.openOrder11=openOrder11;window.saveOrder11=saveOrder11;
  // V26 performance: legacy V11 bootstrap is disabled. The canonical app.js boot owns /api/bootstrap.
  // Keeping this legacy reload on a timer caused late /api/v9/bootstrap responses to overwrite the active V26 view.
  document.addEventListener('DOMContentLoaded',()=>{nav();});
  // V26.0.3: no legacy timed re-render. The canonical app.js owns navigation and rendering.
  // A timer here caused delayed legacy renders to overwrite the active V26 screen.
  window.sbcRestoreVerifiedLeads=async function(){
    const request=typeof window.api==='function'?window.api:api;
    try{
      const status=await request('/api/owner/recovery/status');
      if(status?.recoveryRequired){window.toast?.('Recovery lock active. No leads were promoted. Reconcile the authoritative pre-corruption backup before restoring any records.');return;}
      const manifest=await request('/api/owner/recovery/promotion-manifest/v6428');
      if(manifest?.recoveryRequired){window.toast?.('Recovery lock active. No leads were promoted.');return;}
      const green=Array.isArray(manifest?.greenCandidateIds)?manifest.greenCandidateIds.map(Number).filter(Number.isFinite):[];
      if(!green.length){window.toast?.('Provenance audit found no GREEN recovery candidates. No database rows were changed.');return;}
      const supplied=window.prompt(`Provenance audit found ${green.length} GREEN candidate(s). Enter only the IDs you reviewed and approve, separated by commas. Available GREEN IDs: ${green.join(', ')}`);
      if(!supplied)return;
      const requested=[...new Set(supplied.split(',').map(x=>Number(x.trim())).filter(Number.isFinite))];
      const selected=requested.filter(id=>green.includes(id));
      if(!selected.length||selected.length!==requested.length){window.toast?.('Selection rejected. Choose only IDs listed as GREEN by the provenance manifest. No database rows were changed.');return;}
      const confirmText=window.prompt(`You selected ${selected.length} GREEN provenance candidate(s). Type RESTORE-VERIFIED-LEADS to authorize this exact selection.`);
      if(confirmText!=='RESTORE-VERIFIED-LEADS'){window.toast?.('Restore cancelled. No database rows were changed.');return;}
      const result=await request('/api/owner/recovery/verified-leads/commit',{method:'POST',body:JSON.stringify({confirm:confirmText,leadMeshIds:selected}),headers:{'Content-Type':'application/json'}});
      if(!result?.ok)throw new Error(result?.message||result?.error||'Restore failed');
      window.toast?.(`Restored ${Number(result.restored?.sourceRecords||0)} explicitly selected GREEN lead(s). The full recovery lock remains active until core reconciliation.`);
      window.location.reload();
    }catch(e){window.toast?.(e?.message||String(e));}
  };

})();
