'use strict';

/**
 * V58.3 checkout.paid consumer.
 * Uses the immutable economic snapshot captured by StorefrontCheckoutEventHandler.
 * No refund/payment mutation is performed here.
 */
class CheckoutEventWorker {
  constructor({ pool } = {}) {
    if (!pool) throw new Error('CheckoutEventWorker requires pool');
    this.pool = pool;
  }

  async process(job) {
    const payload = typeof job.payload === 'string' ? JSON.parse(job.payload) : (job.payload || {});
    const tenantId = String(payload.tenant_id || '');
    if (!tenantId) throw new Error('CHECKOUT_TENANT_CONTEXT_REQUIRED');

    const connection = await this.pool.getConnection();
    try {
      await connection.beginTransaction();

      const [rows] = await connection.query(
        `SELECT * FROM sbc_checkout_event_ledger
          WHERE id = ? AND tenant_id = ?
          LIMIT 1 FOR UPDATE`,
        [payload.checkout_ledger_id, tenantId]
      );
      if (!rows.length) {
        await connection.rollback();
        return { status: 'SKIPPED_NO_CHECKOUT_LEDGER' };
      }

      const checkout = rows[0];
      if (Number(checkout.vendor_cost || 0) <= 0 || Number(checkout.margin_pct || 0) < 0.30) {
        await connection.query(
          `UPDATE sbc_checkout_event_ledger
              SET status = 'FROZEN_ECONOMIC_GUARD'
            WHERE id = ? AND tenant_id = ?`,
          [checkout.id, tenantId]
        );
        await connection.commit();
        return { status: 'FROZEN_ECONOMIC_GUARD', checkout_id: checkout.id };
      }

      const [existing] = await connection.query(
        `SELECT id FROM sbc_fulfillment_tasks
          WHERE checkout_ledger_id = ? AND tenant_id = ?
          LIMIT 1`,
        [checkout.id, tenantId]
      );

      let fulfillmentId = existing[0]?.id || null;
      if (!fulfillmentId) {
        const [created] = await connection.query(
          `INSERT INTO sbc_fulfillment_tasks
            (tenant_id, checkout_ledger_id, order_id, customer_id, lead_id, sku, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'PENDING', NOW())`,
          [tenantId, checkout.id, checkout.order_id, checkout.customer_id, checkout.lead_id, checkout.sku]
        );
        fulfillmentId = created.insertId;
      }

      await connection.query(
        `UPDATE sbc_checkout_event_ledger
            SET status = 'FULFILLMENT_QUEUED'
          WHERE id = ? AND tenant_id = ?`,
        [checkout.id, tenantId]
      );

      await connection.commit();
      return { status: 'FULFILLMENT_QUEUED', checkout_id: checkout.id, fulfillment_id: fulfillmentId };
    } catch (err) {
      try { await connection.rollback(); } catch (_) {}
      throw err;
    } finally {
      connection.release();
    }
  }
}

module.exports = CheckoutEventWorker;
